#This is the web application project in CW1.
#Here i build the web application for mascots and costume business.

<?php

$conn = mysqli_connect('localhost','root','','naresh_db') or die('connection failed');

?>